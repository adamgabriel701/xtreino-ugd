CREATE TABLE `admins` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`username` text NOT NULL,
	`password_hash` text NOT NULL,
	`role` text DEFAULT 'admin' NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `admins_username_unique` ON `admins` (`username`);--> statement-breakpoint
CREATE TABLE `championship_teams` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`championship_id` integer NOT NULL,
	`team_id` integer NOT NULL,
	`group_name` text,
	`points` integer DEFAULT 0 NOT NULL,
	`kills` integer DEFAULT 0 NOT NULL,
	`wins` integer DEFAULT 0 NOT NULL,
	`matches_played` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `championships` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`modality` text NOT NULL,
	`format` text NOT NULL,
	`status` text DEFAULT 'em_breve' NOT NULL,
	`start_date` text,
	`end_date` text,
	`rules` text,
	`prize_pool` text,
	`max_teams` integer DEFAULT 16 NOT NULL,
	`registered_teams` integer DEFAULT 0 NOT NULL,
	`bracket_data` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `matches` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`championship_id` integer NOT NULL,
	`team1_id` integer,
	`team2_id` integer,
	`round` integer DEFAULT 1 NOT NULL,
	`bracket_type` text DEFAULT 'winners',
	`team1_score` integer DEFAULT 0 NOT NULL,
	`team2_score` integer DEFAULT 0 NOT NULL,
	`status` text DEFAULT 'pendente' NOT NULL,
	`scheduled_date` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `players` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`nickname` text NOT NULL,
	`uid` text,
	`discord` text,
	`team_id` integer,
	`kills` integer DEFAULT 0 NOT NULL,
	`deaths` integer DEFAULT 0 NOT NULL,
	`wins` integer DEFAULT 0 NOT NULL,
	`matches` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `rankings` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`entity_type` text NOT NULL,
	`entity_id` integer NOT NULL,
	`entity_name` text NOT NULL,
	`points` integer DEFAULT 0 NOT NULL,
	`kills` integer DEFAULT 0 NOT NULL,
	`wins` integer DEFAULT 0 NOT NULL,
	`participations` integer DEFAULT 0 NOT NULL,
	`kd_ratio` real,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `registrations` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`type` text NOT NULL,
	`team_name` text NOT NULL,
	`team_tag` text,
	`captain_name` text,
	`captain_discord` text,
	`whatsapp` text,
	`team_logo` text,
	`event_type` text NOT NULL,
	`event_id` integer NOT NULL,
	`players_data` text,
	`reserves_data` text,
	`status` text DEFAULT 'pendente' NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `scrims` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`team1_id` integer,
	`team2_id` integer,
	`date` text,
	`time` text,
	`modality` text,
	`status` text DEFAULT 'agendado' NOT NULL,
	`result` text,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`org_name` text DEFAULT 'Devils Mobile League' NOT NULL,
	`org_logo` text,
	`org_banner` text,
	`discord_link` text,
	`whatsapp_link` text,
	`default_rules` text,
	`default_times_mx` text,
	`default_times_br` text,
	`primary_color` text DEFAULT '#ff3b3b' NOT NULL,
	`whatsapp_template` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `teams` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`tag` text NOT NULL,
	`logo` text,
	`captain_name` text,
	`captain_discord` text,
	`whatsapp` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `xtreino_teams` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`xtreino_id` integer NOT NULL,
	`team_id` integer NOT NULL,
	`is_reserve` integer DEFAULT false NOT NULL,
	`slot_number` integer,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `xtreinos` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`date` text NOT NULL,
	`time_mx` text,
	`time_br` text,
	`modality` text NOT NULL,
	`max_teams` integer DEFAULT 20 NOT NULL,
	`rules` text,
	`discord_link` text,
	`whatsapp_link` text,
	`status` text DEFAULT 'aberto' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
