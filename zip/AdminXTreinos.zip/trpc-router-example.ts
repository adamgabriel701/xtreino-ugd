// ============================================================
// tRPC ROUTER - XTreinos (com inscrições e times fixos)
// Adicione isso ao seu router principal
// ============================================================

import { z } from "zod";
import { publicProcedure, router } from "../trpc";
import { xtreinos, settings, teams, teamRegistrations } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export const xtreinosRouter = router({
  // --- Queries existentes ---
  list: publicProcedure.query(async ({ ctx }) => {
    return ctx.db.select().from(xtreinos).all();
  }),

  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input, ctx }) => {
      const xt = await ctx.db.select().from(xtreinos).where(eq(xtreinos.id, input.id)).get();
      if (!xt) return null;

      const results = await ctx.db.select().from(xtreinoResults).where(eq(xtreinoResults.xtreinoId, input.id)).all();
      const playerStats = await ctx.db.select().from(xtreinoPlayerStats).where(eq(xtreinoPlayerStats.xtreinoId, input.id)).all();
      const registrations = await ctx.db.select().from(teamRegistrations).where(eq(teamRegistrations.xtreinoId, input.id)).all();

      return { ...xt, results, playerStats, registrations };
    }),

  listResults: publicProcedure.query(async ({ ctx }) => {
    return ctx.db.select().from(xtreinoResults).all();
  }),

  listPlayerStats: publicProcedure.query(async ({ ctx }) => {
    return ctx.db.select().from(xtreinoPlayerStats).all();
  }),

  // --- Mutations existentes ---
  create: publicProcedure
    .input(z.object({
      name: z.string(), date: z.string(), timeMx: z.string().optional(),
      timeBr: z.string().optional(), modality: z.string(),
      maxTeams: z.number(), rules: z.string().optional(),
      discordLink: z.string().optional(), whatsappLink: z.string().optional(),
      status: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      return ctx.db.insert(xtreinos).values(input).run();
    }),

  update: publicProcedure
    .input(z.object({
      id: z.number(), name: z.string(), date: z.string(),
      timeMx: z.string().optional(), timeBr: z.string().optional(),
      modality: z.string(), maxTeams: z.number(),
      rules: z.string().optional(), discordLink: z.string().optional(),
      whatsappLink: z.string().optional(), status: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { id, ...data } = input;
      return ctx.db.update(xtreinos).set(data).where(eq(xtreinos.id, id)).run();
    }),

  delete: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      return ctx.db.delete(xtreinos).where(eq(xtreinos.id, input.id)).run();
    }),

  addResult: publicProcedure
    .input(z.object({
      xtreinoId: z.number(), date: z.string(), teamName: z.string(),
      q1Pos: z.number().optional(), q2Pos: z.number().optional(),
      q3Pos: z.number().optional(), totalPoints: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      return ctx.db.insert(xtreinoResults).values(input).run();
    }),

  addPlayerStats: publicProcedure
    .input(z.object({
      xtreinoId: z.number(), date: z.string(), teamName: z.string(),
      playerName: z.string(), q1Kills: z.number(), q2Kills: z.number(),
      q3Kills: z.number(), totalKills: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      return ctx.db.insert(xtreinoPlayerStats).values(input).run();
    }),

  // --- 🆕 NOVO: Inscrições de Times ---
  registerTeam: publicProcedure
    .input(z.object({
      xtreinoId: z.number(),
      teamName: z.string(),
      isFixed: z.boolean(),
    }))
    .mutation(async ({ input, ctx }) => {
      // Verificar se já existe
      const existing = await ctx.db.select()
        .from(teamRegistrations)
        .where(and(
          eq(teamRegistrations.xtreinoId, input.xtreinoId),
          eq(teamRegistrations.teamName, input.teamName)
        ))
        .get();

      if (existing) throw new Error("Time já inscrito neste xtreino");

      // Contar confirmados para posição
      const confirmed = await ctx.db.select()
        .from(teamRegistrations)
        .where(and(
          eq(teamRegistrations.xtreinoId, input.xtreinoId),
          eq(teamRegistrations.status, "confirmed")
        ))
        .all();

      const position = confirmed.length + 1;
      const status = position <= 10 ? "confirmed" : "reserve";

      return ctx.db.insert(teamRegistrations).values({
        xtreinoId: input.xtreinoId,
        teamName: input.teamName,
        isFixed: input.isFixed,
        position,
        status,
        registeredAt: new Date().toISOString(),
      }).run();
    }),

  unregisterTeam: publicProcedure
    .input(z.object({
      xtreinoId: z.number(),
      teamName: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      return ctx.db.delete(teamRegistrations)
        .where(and(
          eq(teamRegistrations.xtreinoId, input.xtreinoId),
          eq(teamRegistrations.teamName, input.teamName)
        ))
        .run();
    }),

  // --- 🆕 NOVO: Times Fixos ---
  toggleFixedTeam: publicProcedure
    .input(z.object({
      teamName: z.string(),
      isFixed: z.boolean(),
    }))
    .mutation(async ({ input, ctx }) => {
      const currentSettings = await ctx.db.select().from(settings).limit(1).get();
      const currentList = currentSettings?.fixedTeamsList 
        ? JSON.parse(currentSettings.fixedTeamsList) 
        : [];

      const updated = input.isFixed
        ? [...new Set([...currentList, input.teamName])]
        : currentList.filter((t: string) => t !== input.teamName);

      if (currentSettings) {
        await ctx.db.update(settings)
          .set({ fixedTeamsList: JSON.stringify(updated) })
          .run();
      } else {
        await ctx.db.insert(settings).values({
          fixedTeamsList: JSON.stringify(updated),
        }).run();
      }

      return { fixedTeams: updated };
    }),

  // --- Schedule ---
  schedule: router({
    list: publicProcedure.query(async ({ ctx }) => {
      return ctx.db.select().from(xtreinoSchedule).all();
    }),

    create: publicProcedure
      .input(z.object({
        date: z.string(), dayOfWeek: z.string(),
        timeBr: z.string(), status: z.string(), notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return ctx.db.insert(xtreinoSchedule).values(input).run();
      }),

    generateMonth: publicProcedure
      .input(z.object({ year: z.number(), month: z.number() }))
      .mutation(async ({ input, ctx }) => {
        // Lógica de geração automática
        const { year, month } = input;
        const generated = 0; // Implementar lógica
        return { generated };
      }),
  }),
});

// --- Settings Router ---
export const settingsRouter = router({
  get: publicProcedure.query(async ({ ctx }) => {
    return ctx.db.select().from(settings).limit(1).get();
  }),

  updateFixedTeams: publicProcedure
    .input(z.object({ teams: z.array(z.string()) }))
    .mutation(async ({ input, ctx }) => {
      const current = await ctx.db.select().from(settings).limit(1).get();
      if (current) {
        await ctx.db.update(settings)
          .set({ fixedTeamsList: JSON.stringify(input.teams) })
          .run();
      } else {
        await ctx.db.insert(settings).values({
          fixedTeamsList: JSON.stringify(input.teams),
        }).run();
      }
      return { success: true };
    }),
});

// --- Teams Router ---
export const teamsRouter = router({
  list: publicProcedure.query(async ({ ctx }) => {
    return ctx.db.select({ name: teams.name, tag: teams.tag }).from(teams).all();
  }),
});
