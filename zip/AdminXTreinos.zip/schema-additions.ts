// ============================================================
// SCHEMA ADICIONAL - Adicionar ao seu schema.ts
// ============================================================

import { sqliteTable, integer, text } from "drizzle-orm/sqlite-core";

// --- Tabela existente: settings (adicionar coluna) ---
export const settings = sqliteTable("settings", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  orgName: text("org_name"),
  discordLink: text("discord_link"),
  whatsappLink: text("whatsapp_link"),
  defaultRules: text("default_rules"),
  defaultTimesMx: text("default_times_mx"),
  defaultTimesBr: text("default_times_br"),
  primaryColor: text("primary_color"),
  whatsappTemplate: text("whatsapp_template"),
  fixedTeamsList: text("fixed_teams_list"),  // <-- NOVO: JSON string ["UGD Threat", ...]
});

// --- 🆕 NOVO: Tabela de inscrições de times ---
export const teamRegistrations = sqliteTable("team_registrations", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  xtreinoId: integer("xtreino_id").notNull(),
  teamName: text("team_name").notNull(),
  isFixed: integer("is_fixed", { mode: "boolean" }).default(false),
  position: integer("position").default(0),
  status: text("status").default("confirmed"), // "confirmed" | "reserve" | "cancelled"
  registeredAt: text("registered_at"),
});

// --- Tabelas existentes (mantidas para referência) ---
export const xtreinos = sqliteTable("xtreinos", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  date: text("date").notNull(),
  timeMx: text("time_mx"),
  timeBr: text("time_br"),
  modality: text("modality").notNull(),
  maxTeams: integer("max_teams").default(20),
  rules: text("rules"),
  discordLink: text("discord_link"),
  whatsappLink: text("whatsapp_link"),
  status: text("status").default("aberto"),
});

export const xtreinoResults = sqliteTable("xtreino_results", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  xtreinoId: integer("xtreino_id").notNull(),
  date: text("date").notNull(),
  teamName: text("team_name").notNull(),
  q1Pos: integer("q1_pos"),
  q2Pos: integer("q2_pos"),
  q3Pos: integer("q3_pos"),
  totalPoints: integer("total_points"),
});

export const xtreinoPlayerStats = sqliteTable("xtreino_player_stats", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  xtreinoId: integer("xtreino_id").notNull(),
  date: text("date").notNull(),
  teamName: text("team_name").notNull(),
  playerName: text("player_name").notNull(),
  q1Kills: integer("q1_kills").default(0),
  q2Kills: integer("q2_kills").default(0),
  q3Kills: integer("q3_kills").default(0),
  totalKills: integer("total_kills").default(0),
});

export const xtreinoSchedule = sqliteTable("xtreino_schedule", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  date: text("date").notNull(),
  dayOfWeek: text("day_of_week").notNull(),
  timeBr: text("time_br").default("21:00"),
  status: text("status").default("scheduled"),
  notes: text("notes"),
});

export const teams = sqliteTable("teams", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull().unique(),
  tag: text("tag").notNull(),
});

export const players = sqliteTable("players", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  nickname: text("nickname").notNull().unique(),
  teamId: integer("team_id"),
});

export const admins = sqliteTable("admins", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").default("admin"),
});

export const seedRuns = sqliteTable("seed_runs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  seedName: text("seed_name").notNull().unique(),
  runAt: text("run_at").default(new Date().toISOString()),
});
