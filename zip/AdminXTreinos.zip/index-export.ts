// ============================================================
// BARREL EXPORT - AdminXTreinos
// Facilita imports: import { AdminXTreinos } from "@/components/AdminXTreinos";
// ============================================================

export { default as AdminXTreinos } from "./index";
export * from "./types";
export * from "./hooks/useXTreinos";
